Before you get started, and if you have a fresh install, be sure to run the default
launcher and setup your graphics options. This will create the needed .ini files
and save you grief later.

Installation instructions:

1. Install Darn
2. Install UIO
3. Install MCM and hide overwrites to Darn in MO2, or do not allow overwrites, UIO takes care of this
3. When installing other hud mods hide their overwrites to Darn or do not allow the overwrites, UIO takes care of this
4. Edit FalloutCustom.ini in your profile as such

[Fonts]
;sFontFile_1=Textures\Fonts\Glow_Monofonto_Large.fnt
sFontFile_1=Textures\Fonts\DarN_FranKleinBold_14.fnt
;sFontFile_2=Textures\Fonts\Monofonto_Large.fnt
sFontFile_2=Textures\Fonts\DarN_FranKleinBold_16.fnt
sFontFile_3=Textures\Fonts\Glow_Monofonto_Medium.fnt
;sFontFile_4=Textures\Fonts\Monofonto_VeryLarge02_Dialogs2.fnt
sFontFile_4=Textures\Fonts\DarN_Sui_Generis_Otl_10.fnt
sFontFile_5=Textures\Fonts\Fixedsys_Comp_uniform_width.fnt
;sFontFile_6=Textures\Fonts\Glow_Monofonto_VL_dialogs.fnt
sFontFile_6=Textures\Fonts\DarN_Sui_Generis_Otl_13.fnt
;sFontFile_7=Textures\Fonts\Baked-in_Monofonto_Large.fnt
sFontFile_7=Textures\Fonts\DarN_Libel_Suit_Otl_24.fnt
sFontFile_8=Textures\Fonts\Glow_Futura_Caps_Large.fnt
sFontFile_9=Textures\Fonts\NVFont_Test.fnt

5. ???
6. Profit!

Optional :

If you don't like the Fallout 3 HUD then delete Data\textures\interface\interfaceshared0.dds

Credits:

DarN - creating the essential DarNified user interface

TJ - starting the project and breaking shit at random

Roy Batty - bug fixing, alterations, and expansion

pintocat - Dynamic Quantity Prompt, Terminal Close Button, Barter Name Fix, other bug fixes, expansion

Alystin - initial adaptation of the scripts from DarN FO3 for use with NV

MamaStankum - DarNified traits menu

Gribbleshnibit8 - xml adjustments and advice, scripting advice

JaxFirehart - ArmorCND fix, xml advice

Gopher - inspiration

jazzisparis - many bug fixes to the xml

Jesus H Christ - menu color fix, armor cnd color fix, scaling for icons

Axonis - fixed start menu to allow longer menu list for hotkeys etc